import greenfoot.*;  // imports Actor, World, ...

public class Crab extends Animal
{
    public void act()
    {
        this.move();
    }
}