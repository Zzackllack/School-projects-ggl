public class Piff {
    public void Ausgabe() {
        System.out.println("piff");
    }
}