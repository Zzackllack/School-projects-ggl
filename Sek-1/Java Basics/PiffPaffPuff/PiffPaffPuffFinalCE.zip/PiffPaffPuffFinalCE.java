public class PiffPaffPuffFinalCE {
    public static void main(String[] args) {
        Piff piffObjekt = new Piff();
        Paff paffObjekt = new Paff();
        Puff puffObjekt = new Puff();

        piffObjekt.Ausgabe();
        paffObjekt.Ausgabe();
        puffObjekt.Ausgabe();
    }
}