public class Puff {
    public void Ausgabe() {
        System.out.println("puff");
    }
}
