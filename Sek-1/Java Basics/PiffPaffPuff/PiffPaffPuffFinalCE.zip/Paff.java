public class Paff {
    public void Ausgabe() {
        System.out.println("paff");
    }
}